import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import styled from '@emotion/styled';
import { T as Theme, M as MediaQuery, F as FadeIn, C as Container } from './index_BauM8CHz.mjs';
import { T as TextBox } from './index_CnZaBIcb.mjs';

const ServiceCardsStyled = styled.section`
    background: ${Theme.primary};
    padding-top: 90px;
    border-top-left-radius: 50px;
    border-top-right-radius: 50px;
    margin: -43px 0 50px;
    z-index: 1;
    position: relative;
`;
const ServiceCardsHeading = styled.div`
    color: ${Theme.secondary};

    margin-bottom: 40px;
    max-width: 550px;

    p {
        color: ${Theme.tertiary};
    }

    h2 {
        font-size: 60px;
        line-height: 1.2;
        margin-bottom: 10px;

        ${MediaQuery.max("lg")} {
            font-size: 40px;
            line-height: 1.2;
        }
    }
`;
const ServiceCardsGrid = styled.div`
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 40px;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    h3 {
        font-size: 20px;
        line-height: 1.2;
        margin-bottom: 5px;
    }

    p {
        margin: 0;
        font-size: 16px;
        line-height: 1.2;
        letter-spacing: -0.5px;
        opacity: 0.8;
    }
`;

const ServiceCards = ({
  cards,
  description,
  title
}) => {
  if (!cards || !cards.length) {
    return null;
  }
  const cardsElements = cards.map((card, index) => {
    return /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs(TextBox, { children: [
      /* @__PURE__ */ jsx("h3", { children: card.title }),
      /* @__PURE__ */ jsx("p", { children: card.description })
    ] }) }, index);
  });
  return /* @__PURE__ */ jsx(ServiceCardsStyled, { children: /* @__PURE__ */ jsxs(Container, { children: [
    title && description && /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs(ServiceCardsHeading, { children: [
      description && /* @__PURE__ */ jsx("p", { children: description }),
      title && /* @__PURE__ */ jsx("h2", { children: title })
    ] }) }),
    /* @__PURE__ */ jsx(ServiceCardsGrid, { children: cardsElements })
  ] }) });
};

export { ServiceCards as S };
