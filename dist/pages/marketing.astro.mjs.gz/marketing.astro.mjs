import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from '../chunks/astro/server_BcZ62ja7.mjs';
import 'kleur/colors';
import 'html-escaper';
import { a as HeroSlider3, I as InfiniteImg1, b as InfiniteImg2, $ as $$Layout } from '../chunks/index_BauM8CHz.mjs';
import { H as Hero } from '../chunks/index_zZxl8W22.mjs';
import 'react/jsx-runtime';
import 'react';
import { S as ServiceCards } from '../chunks/index_Dcfu2D3H.mjs';
import { F as Footer } from '../chunks/index_BVS5Lk85.mjs';
export { renderers } from '../renderers.mjs';

const $$Marketing = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Cybernetic | Homepage", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:visible": true, "data": {
    image: HeroSlider3.src,
    content: {
      title: "INFINITE",
      paragraph: "Infinite is a platform that allows you to create a unlimited space for your community. It is a place where you can share your thoughts, ideas, and experiences with like-minded people."
    }
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} <br><br> ${renderComponent($$result2, "ServiceCards", ServiceCards, { "description": "SERVICES", "title": "The Service We Provide For You", "client:visible": true, "cards": [
    {
      title: "Cyber - development",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Security",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Marketing",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Development",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Security",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Marketing",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@modules/ServiceCards", "client:component-export": "ServiceCards" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: InfiniteImg1.src,
      width: 590,
      height: 300,
      alt: "Hero Image"
    },
    title: "Lets make you Infinite!",
    paragraph: "Become a part of the Infinite community and start sharing your thoughts, ideas, and experiences with like-minded people."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    switchPlaces: true,
    image: {
      src: InfiniteImg2.src,
      width: 590,
      height: 300,
      alt: "Hero Image"
    },
    title: "Infinite Community",
    paragraph: "with infinite dashboard you can easily manage your community, create posts, and interact with your followers."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "/Users/goon/Desktop/ELR Agency MKT/ELR-Agency/ELR Agency Clients/newelr/src/pages/marketing.astro", void 0);

const $$file = "/Users/goon/Desktop/ELR Agency MKT/ELR-Agency/ELR Agency Clients/newelr/src/pages/marketing.astro";
const $$url = "/marketing";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Marketing,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
