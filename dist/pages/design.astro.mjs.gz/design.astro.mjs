import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from '../chunks/astro/server_BcZ62ja7.mjs';
import 'kleur/colors';
import 'html-escaper';
import 'react/jsx-runtime';
import 'react';
import { a as HeroSlider3, I as InfiniteImg1, b as InfiniteImg2, $ as $$Layout } from '../chunks/index_BauM8CHz.mjs';
import { H as Hero } from '../chunks/index_IlsPCrFA.mjs';
import { S as ServiceCards } from '../chunks/index_Dcfu2D3H.mjs';
export { renderers } from '../renderers.mjs';

const $$Design = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Design Web | Cr\xE9ation de site web sur mesure par l'agence ELR", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "client:load": true, "heroType": "fullPageSlider", "data": [
    {
      subtitle: "Une solution compl\xE8te pour d\xE9velopper votre entreprise en ligne",
      title: "Site web",
      background: HeroSlider3.src,
      paragraph: "Du simple redesign \xE0 la cr\xE9ation compl\xE8te, nous sommes pr\xEAt \xE0 vous aider avec des concepts uniques et innovants qui sauront charmer votre audience."
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} <br><br> ${renderComponent($$result2, "ServiceCards", ServiceCards, { "description": "SERVICES", "title": "The Service We Provide For You", "client:visible": true, "cards": [
    {
      title: "Cyber - development",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Security",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Marketing",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Development",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Security",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Marketing",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@modules/ServiceCards", "client:component-export": "ServiceCards" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: InfiniteImg1.src,
      width: 590,
      height: 300,
      alt: "Hero Image"
    },
    title: "Lets make you Infinite!",
    paragraph: "Become a part of the Infinite community and start sharing your thoughts, ideas, and experiences with like-minded people."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    switchPlaces: true,
    image: {
      src: InfiniteImg2.src,
      width: 590,
      height: 300,
      alt: "Hero Image"
    },
    title: "Infinite Community",
    paragraph: "with infinite dashboard you can easily manage your community, create posts, and interact with your followers."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ` })}`;
}, "/Users/goon/Desktop/ELR Agency MKT/ELR-Agency/ELR Agency Clients/newelr/src/pages/design.astro", void 0);

const $$file = "/Users/goon/Desktop/ELR Agency MKT/ELR-Agency/ELR Agency Clients/newelr/src/pages/design.astro";
const $$url = "/design";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Design,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
