import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from '../chunks/astro/server_BcZ62ja7.mjs';
import 'kleur/colors';
import 'html-escaper';
import 'react/jsx-runtime';
import 'react';
import { H as HeroSlider1, a as HeroSlider3, $ as $$Layout } from '../chunks/index_BauM8CHz.mjs';
import { H as Hero } from '../chunks/index_Le77Wrdz.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Agence ELR | L'agence pour PME par excellence", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "client:load": true, "heroType": "fullPageSlider", "data": [
    {
      subtitle: "Lib\xE9rez-vous des t\xE2ches marketing, concentrez-vous sur ce que vous faites le mieux",
      title: "Agence ELR",
      background: HeroSlider1.src,
      paragraph: "Offrez-vous les moyens de faire grandir votre entreprise",
      button: {
        text: "D\xE9couvrez nos capacit\xE9s",
        link: "/services"
      }
    },
    {
      subtitle: "Une solution compl\xE8te pour d\xE9velopper votre entreprise en ligne",
      title: "Site web",
      background: HeroSlider3.src,
      paragraph: "Du simple redesign \xE0 la cr\xE9ation compl\xE8te, nous sommes pr\xEAt \xE0 vous aider avec des concepts uniques et innovants qui sauront charmer votre audience.",
      button: {
        text: "Jetez un coup d'oeil",
        link: "/design"
      }
    },
    {
      subtitle: "Rejoignez vos clients potentiels, peu importe ou ils sont",
      title: "Marketing",
      background: HeroSlider3.src,
      paragraph: "Concentrez-vous sur votre c\u0153ur de m\xE9tier pendant que nous faisons grandir votre entreprise",
      button: {
        text: "En savoir plus!",
        link: "/marketing"
      }
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ` })}`;
}, "/Users/goon/Desktop/ELR Agency MKT/ELR-Agency/ELR Agency Clients/newelr/src/pages/index.astro", void 0);

const $$file = "/Users/goon/Desktop/ELR Agency MKT/ELR-Agency/ELR Agency Clients/newelr/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
